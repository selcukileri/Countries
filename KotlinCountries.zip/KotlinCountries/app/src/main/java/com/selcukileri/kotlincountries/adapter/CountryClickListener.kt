package com.selcukileri.kotlincountries.adapter

import android.view.View

interface CountryClickListener {
    fun onCountryClicked(v: View)
}